# Recommended GitHub Repository Structure

```
tft-coach-companion/
├── README.md                           # TFT_COACH_PROJECT_HANDOFF.md content
├── DATA_SCHEMAS.md                     # Schema documentation
│
├── data/
│   ├── personal/                       # YOUR match data
│   │   ├── tft_since_16_2_enhanced.csv
│   │   ├── carry_performance_corrected.csv
│   │   ├── trait_performance_corrected.csv
│   │   └── item_performance_corrected.csv
│   │
│   ├── game_data/                      # CommunityDragon Set 16 data
│   │   ├── champions.jsonl
│   │   ├── champion_traits.jsonl
│   │   ├── ability_variables.jsonl
│   │   ├── traits.jsonl
│   │   ├── trait_effects.jsonl
│   │   ├── items.jsonl
│   │   ├── augments.jsonl
│   │   └── set16_all_records.jsonl
│   │
│   ├── meta/                           # Current patch meta data
│   │   ├── set16_champions_shop_16_3.jsonl
│   │   ├── set16_augments_16_3.jsonl
│   │   ├── set16_items_16_3.jsonl
│   │   ├── set16_traits.jsonl
│   │   ├── metatft_augment_tierlist_16_3.csv
│   │   ├── tft_set16_3_early_game_stage2_stage3.csv
│   │   └── tft_set16_3_early_game_stage4_stage5.csv
│   │
│   └── manifest.json                   # Data provenance
│
├── src/
│   ├── data_parsing/
│   │   └── tft_diagnostic.py           # Existing parsing utilities
│   │
│   ├── models/                         # ML models (to build)
│   │   ├── placement_predictor.py
│   │   └── feature_engineering.py
│   │
│   └── ui/                             # React frontend
│       └── components/
│
├── design/
│   ├── TFT_Coach_Figma_Spec.md
│   ├── TFT_Coach_Component_Outline.js
│   ├── Figma_Resources_Guide.md
│   └── tft_dashboard.html              # Reference dashboard
│
├── notebooks/                          # Analysis notebooks (optional)
│   └── exploration.ipynb
│
└── requirements.txt                    # Python dependencies
```

## Initial Setup Commands for Claude Code

```bash
# Clone and navigate
cd tft-coach-companion

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install pandas numpy scikit-learn xgboost matplotlib seaborn

# Verify data loads
python -c "import pandas as pd; df = pd.read_csv('data/personal/tft_since_16_2_enhanced.csv'); print(f'Loaded {len(df)} matches')"
```

## Priority Tasks for Claude Code

1. **Feature Engineering** (`src/models/feature_engineering.py`)
   - Parse traits_active → one-hot encoding
   - Parse final_board_units → cost distribution, star levels, item counts
   - Create carry identification features
   - Engineer game state features (level, gold efficiency, round survival)

2. **Placement Prediction Model** (`src/models/placement_predictor.py`)
   - Train XGBoost regressor on placement (1-8)
   - Threshold to top4/bottom4 classification
   - Cross-validation (5-fold given small dataset)
   - Feature importance analysis

3. **Validation**
   - Confirm model validates known patterns (AP > AD carries)
   - Test on held-out games
   - Generate recommendation rules from feature importance
